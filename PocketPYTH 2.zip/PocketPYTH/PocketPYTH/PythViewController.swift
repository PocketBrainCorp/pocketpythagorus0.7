//
//  PythViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 19.10.2021.
//

import UIKit

class PythViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func GoToConst(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is ConstViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
